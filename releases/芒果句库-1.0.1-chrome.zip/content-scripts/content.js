(function(){function e(e){return e}var t=`sentence-memory-overlay-host`,n=class{host=null;shadow=null;handlers=null;show(e,t,n){this.handlers=n,this.ensureHost(),this.render(t),this.position(e)}update(e){this.shadow&&this.render(e)}hide(){this.host?.remove(),this.host=null,this.shadow=null,this.handlers=null}contains(e){return!!this.host&&e instanceof Node&&this.host.contains(e)}ensureHost(){if(this.host&&this.shadow)return;document.getElementById(t)?.remove();let e=document.createElement(`div`);e.id=t,e.style.all=`initial`,e.style.position=`fixed`,e.style.zIndex=`2147483647`,e.style.top=`0`,e.style.left=`0`,document.documentElement.appendChild(e),this.host=e,this.shadow=e.attachShadow({mode:`open`})}render(e){if(!this.shadow)return;let t=e.status===`loading`||e.status===`saved`||e.status===`exists`||e.status===`error`,n=e.status===`saved`?`已保存`:e.status===`exists`?`已存在`:`保存到芒果句库`;this.shadow.innerHTML=`
      <style>
        :host { all: initial; }
        * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
        .panel {
          width: min(360px, calc(100vw - 16px));
          max-height: 240px;
          overflow: auto;
          background: #fff;
          color: #1f2937;
          border-radius: 10px;
          box-shadow: 0 8px 28px rgba(15, 23, 42, 0.18);
          border: 1px solid rgba(15, 23, 42, 0.08);
          padding: 12px;
        }
        .text {
          font-size: 14px;
          line-height: 1.55;
          white-space: pre-wrap;
          word-break: break-word;
          margin: 0 0 10px;
        }
        .meta {
          font-size: 12px;
          color: #6b7280;
          margin: 0 0 10px;
        }
        .actions {
          display: flex;
          gap: 8px;
          justify-content: flex-end;
        }
        button {
          border: 0;
          border-radius: 8px;
          padding: 6px 12px;
          font-size: 13px;
          cursor: pointer;
        }
        .save {
          background: #0f766e;
          color: #fff;
        }
        .save:disabled {
          opacity: 0.65;
          cursor: default;
        }
        .close {
          background: #e5e7eb;
          color: #111827;
        }
        @media (prefers-color-scheme: dark) {
          .panel {
            background: #111827;
            color: #f3f4f6;
            border-color: rgba(255,255,255,0.08);
            box-shadow: 0 10px 30px rgba(0,0,0,0.45);
          }
          .meta { color: #9ca3af; }
          .close { background: #374151; color: #f9fafb; }
          .save { background: #14b8a6; color: #042f2e; }
        }
      </style>
      <div class="panel" part="panel">
        <p class="text">${r(e.translation||(e.status===`loading`?`翻译中…`:``))}</p>
        ${e.message?`<p class="meta">${r(e.message)}</p>`:e.progress===void 0?``:`<p class="meta">模型下载中 ${Math.round(e.progress*100)}%</p>`}
        <div class="actions">
          <button class="close" type="button" data-action="close">关闭</button>
          <button class="save" type="button" data-action="save" ${t?`disabled`:``}>${n}</button>
        </div>
      </div>
    `,this.shadow.querySelector(`[data-action="close"]`)?.addEventListener(`click`,()=>{this.handlers?.onClose()}),this.shadow.querySelector(`[data-action="save"]`)?.addEventListener(`click`,()=>{this.handlers?.onSave()})}position(e){if(!this.host||!this.shadow)return;let t=this.shadow.querySelector(`.panel`);if(!t)return;let n=t.getBoundingClientRect(),r=window.innerWidth,i=window.innerHeight,a=e.bottom+8;a+n.height>i-8&&(a=e.top-n.height-8),a=Math.max(8,Math.min(a,i-n.height-8));let o=e.left;o+n.width>r-8&&(o=r-n.width-8),o=Math.max(8,o),this.host.style.top=`${a}px`,this.host.style.left=`${o}px`}};function r(e){return e.replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`).replaceAll(`'`,`&#39;`)}var i=`1.0.0`,a={sourceLanguage:`en`,targetLanguage:`zh`,dailyReviewLimit:20,autoSave:!1},o={OpenReview:`OPEN_REVIEW`,TranslateAndSave:`TRANSLATE_AND_SAVE`,GetDueCount:`GET_DUE_COUNT`,SaveResultNotify:`SAVE_RESULT_NOTIFY`,Translate:`TRANSLATE`,WarmUpTranslator:`WARM_UP_TRANSLATOR`,OffscreenTranslate:`OFFSCREEN_TRANSLATE`,OffscreenWarmUp:`OFFSCREEN_WARM_UP`,OffscreenPing:`OFFSCREEN_PING`,TranslateProgress:`TRANSLATE_PROGRESS`},s=/[A-Za-z]/,c=.4;function l(){return typeof crypto<`u`&&typeof crypto.randomUUID==`function`?crypto.randomUUID():`id_${Date.now()}_${Math.random().toString(36).slice(2,10)}`}function u(e){let t=e.trim();if(!t||!s.test(t))return!1;let n=t.replace(/[^A-Za-z\u4e00-\u9fff]/g,``);return n?(n.match(/[A-Za-z]/g)??[]).length/n.length>=c:!1}function d(e=Date.now()){return{times:0,correct:0,consecutiveCorrect:0,nextReviewAt:e,intervalLevel:0}}var f=`sentences`,p=`settings`,m=`version`;async function h(e,t){return(await chrome.storage.local.get(e))[e]??t}async function g(){return h(p,a)}async function _(){return h(f,[])}async function v(e){await chrome.storage.local.set({[f]:e,[m]:i})}async function y(e){let t=await _(),n=Date.now(),r=t.findIndex(t=>t.url===e.url&&t.en===e.en);if(r>=0){let i=t[r];if(i.zh===e.zh)return{status:`exists`,sentence:i};let a={...i,zh:e.zh,updatedAt:n};return t[r]=a,await v(t),{status:`updated`,sentence:a}}let i={id:l(),en:e.en,zh:e.zh,url:e.url,pageTitle:e.pageTitle,createdAt:n,updatedAt:n,tags:e.tags,review:d(n)};return t.unshift(i),await v(t),{status:`created`,sentence:i}}async function b(e,t,n){let r=await chrome.runtime.sendMessage({type:o.Translate,text:e,sourceLanguage:t,targetLanguage:n});if(!r?.ok)throw Error(r?.error||`翻译失败`);return r.translation}var x=180,S=e({matches:[`<all_urls>`],runAt:`document_idle`,main(){let e=new n,t,r=``,i=``,a=0,s=()=>{let e=window.getSelection();e&&e.rangeCount!==0&&e.removeAllRanges()},c=n=>{window.clearTimeout(t),t=void 0,a+=1,e.hide(),r=``,i=``,n?.clearSelection!==!1&&s()},l=(e,t)=>{chrome.runtime.sendMessage({type:o.SaveResultNotify,title:e,message:t})},d=async(e,t)=>y({en:e,zh:t,url:location.href,pageTitle:document.title}),f=async()=>{if(r&&i){e.update({translation:i,status:`loading`,message:`保存中…`});try{await d(r,i),c()}catch(t){e.update({translation:i,status:`error`,message:t instanceof Error?t.message:`保存失败`})}}},p=async(t,n)=>{let o=++a;r=t,i=``,e.show(n,{translation:``,status:`loading`,message:`翻译中…`},{onSave:()=>void f(),onClose:c});try{let n=await g(),r=await b(t,n.sourceLanguage,n.targetLanguage);if(o!==a)return;i=r,e.update({translation:r,status:`idle`}),n.autoSave&&await f()}catch(n){if(o!==a)return;e.update({translation:t,status:`error`,message:n instanceof Error?n.message:`翻译失败，请重试或复制原文`})}},m=async e=>{try{let t=await g(),n=await b(e,t.sourceLanguage,t.targetLanguage),r=await d(e,n),i=r.status===`exists`?`芒果句库：已存在`:r.status===`updated`?`芒果句库：已更新`:`芒果句库：已保存`;l(i,n.slice(0,120))}catch(e){l(`芒果句库：保存失败`,e instanceof Error?e.message:`请稍后重试`)}};document.addEventListener(`mouseup`,n=>{e.contains(n.target)||(window.clearTimeout(t),t=window.setTimeout(()=>{let e=window.getSelection(),t=e?.toString().trim()??``;if(!t||!u(t)||!e||e.rangeCount===0)return;let n=e.getRangeAt(0).getBoundingClientRect();(n.width!==0||n.height!==0)&&p(t,n)},x))}),document.addEventListener(`mousedown`,t=>{e.contains(t.target)||c()},!0),document.addEventListener(`keydown`,e=>{e.key===`Escape`&&c()}),chrome.runtime.onMessage.addListener((t,n,r)=>{if(t?.type===o.TranslateAndSave&&t.text)return m(String(t.text)).then(()=>{r({ok:!0})}),!0;if(t?.type===o.TranslateProgress){let n=Number(t.loaded??0);return e.update({translation:``,status:`loading`,progress:n,message:`模型下载中 ${Math.round(n*100)}%`}),!1}return!1})}}),C={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},w=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,T=class e extends Event{static EVENT_NAME=E(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function E(e){return`${w?.runtime?.id}:content:${e}`}var D=typeof globalThis.navigation?.addEventListener==`function`;function O(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),D?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new T(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new T(e,t)),t=e)},1e3))}}}var k=class e{static SCRIPT_STARTED_MESSAGE_TYPE=E(`wxt:content-script-started`);id;abortController;locationWatcher=O(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return w.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?E(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),C.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},A={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=S;return await e(new k(`content`,t))}catch(e){throw A.error(`The content script "content" crashed on startup!`,e),e}})()})();